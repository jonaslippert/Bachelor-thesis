# Set up Naproche

## Set up the command line interface

* Clone the Naproche repository:

  ```sh
  git clone https://github.com/naproche-community/naproche.git
  ```

* Build Naproche:

  ```sh
  cd naproche
  stack clean
  stack build
  ```


## Set up the Isabelle integration (optional)

* Leave the Naproche directory (not necessary, but recommended), e.g.:

  ```sh
  cd
  ```

* Initialize a fresh Isabelle clone:

  ```sh
  hg clone https://isabelle.sketis.net/repos/isabelle-release isabelle
  cd isabelle
  hg update -C -r Isabelle2021
  ./bin/isabelle components -I
  ./bin/isabelle components -a
  ```

* Add Isabelle to your path, e.g:

  ```sh
  ln -s "$(pwd)/bin/isabelle" ~/.local/bin/isabelle
  ```

* Remove existing Isabelle components:

  Ensure there is no reference to the Naproche directory in `~/.isabelle/etc/settings`, e.g.

  ```sh
  sed -i -e 's/init_component.*\/[Nn]aproche\(-SAD\)\?//g' ~/.isabelle/etc/settings
  ```

  Alternatively, remove all entries of the form `init_component .../naproche` or `init_component .../Naproche-SAD` and the like by hand.

* Update the reference to the Naproche repository:

  ```sh
  isabelle components -u ~/naproche # adapt the path accordingly
  ```

* Build Isabelle/Naproche:

  ```sh
  isabelle naproche_build
  ```
