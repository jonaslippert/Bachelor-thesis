# E

Set up [E](https://wwwlehre.dhbw-stuttgart.de/~sschulz/E/E.html) as ATP for
Naproche's command line interface.

It might be necessary to add the directory `~/.local/bin` to your path in order to successfully work through the following steps.

---

If you have set up the Isabelle integration of Naproche, just put the binary of E that comes with it into your path, e.g.:

```sh
ln -s "$(isabelle getenv -b E_HOME)" ~/.local/bin/eprover
```

---

If you have not set up the Isabelle integration, you can download and build E manually:

* Download E:

  ```sh
  wget http://wwwlehre.dhbw-stuttgart.de/~sschulz/WORK/E_DOWNLOAD/V_2.5/E.tgz
  ```

* Unpack:

  ```sh
  tar -xzf E.tgz
  rm E.tgz
  cd E
  ```

* Build:

  ```sh
  ./configure
  make rebuild
  ```

* Put the binary into your path, e.g.:

  ```sh
  ln -s "$(pwd)/PROVER/eprover" ~/.local/bin/eprover
  ```
