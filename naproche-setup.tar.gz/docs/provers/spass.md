# SPASS

Set up [SPASS](https://www.mpi-inf.mpg.de/departments/automation-of-logic/software/spass-workbench)
as ATP for Naproche's command line interface.

---

If you have set up the Isabelle integration of Naproche, just put the binary
of SPASS that comes with it into your path, e.g.:

```sh
ln -s "$(isabelle getenv -b SPASS_HOME)" ~/.local/bin/eprover
```

---

If you have not set up the Isabelle integration, you can download and build
SPASS manually:

* Download SPASS:

  ```sh
  mkdir SPASS
  cd SPASS
  wget http://www.spass-prover.org/download/sources/spass39.tgz
  ```

* Unpack:

  ```sh
  tar -xzf spass39.tgz
  rm spass39.tgz
  ```

* Build:

  ```sh
  make
  ```

* Put the binary into your path, e.g.:

  ```sh
  ln -s "$(pwd)/SPASS" ~/.local/bin/SPASS
  ```

* Set SPASS as your default ATP for Naproche (optional):

  Open the file `Naproche/init.opt` in a text editor and change the line
  `[prover eprover]` to `[prover spass]`.
