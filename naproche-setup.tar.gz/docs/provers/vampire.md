# Vampire

Set up [Vampire](https://vprover.github.io/index.html) as ATP for Naproche's
command line interface.

---

If you have set up the Isabelle integration of Naproche, just put the binary
of Vampire that comes with it into your path, e.g.:

```sh
ln -s "$(isabelle getenv -b Vampire_HOME)" ~/.local/bin/eprover
```

---

If you have not set up the Isabelle integration, you can download Vampire
manually:

* Download Vampire:

  ```sh
  mkdir Vampire
  cd Vampire
  wget https://vprover.github.io/bin/vampire4.2.2
  ```

* Make Vampire executable:

  ```sh
  chmod +x vampire4.2.2
  ```

* Put the binary into your path, e.g.:

  ```sh
  ln -s "$(pwd)/vampire4.2.2" ~/.local/bin/vampire4.2.2
  ```

* Set Vampire as your default ATP for Naproche (optional):

  Open the file `Naproche/init.opt` in a text editor and change the line
  `[prover eprover]` to `[prover vampire]`.
