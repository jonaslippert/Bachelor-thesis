# Linux

Naproche comes with a command line interface and an (optional) integration into
[Isabelle](https://isabelle.in.tum.de/) which provides a graphical interface
via [jEdit](http://www.jedit.org/).


## Install required tools and libraries

Depending on your distribution different tools and libraries are required to
build Naproche. In the subsequent paragraphs you can find detailed instructions
on how to install them on some of the most common ones:

  * [Debian](#debian)
  * [Fedora](#fedora)
  * [Linux Mint](#linux-mint)
  * [Manjaro](#manjaro)
  * [openSUSE](#opensuse)
  * [Ubuntu](#ubuntu)

If your distribution is not listed, follow the instructions in the section [_Generic_](#generic).


### Debian

Install the following packages:

* Stack:

  ```sh
  wget -qO- https://get.haskellstack.org/ | sh
  ```

* Git:

  ```sh
  sudo apt-get install git
  ```

* Mercurial (only required for the Isabelle integration):

  ```sh
  sudo apt-get install mercurial
  ```

* Curl (only required for the Isabelle integration):

  ```sh
  sudo apt-get install curl
  ```


### Fedora

Install the following packages:

* Stack:

  ```sh
  wget -qO- https://get.haskellstack.org/ | sh
  ```

* Mercurial (only required for the Isabelle integration):

  ```sh
  sudo dnf install mercurial
  ```


### Linux Mint

Install the following packages:

* Stack:

  ```sh
  wget -qO- https://get.haskellstack.org/ | sh
  ```

* Git:

  ```sh
  sudo apt-get install git
  ```

* Mercurial (only required for the Isabelle integration):

  ```sh
  sudo apt-get install mercurial
  ```

* Build-essential (only required for the Isabelle integration):

  ```sh
  sudo apt-get install build-essential
  ```


### Manjaro

Install the following packages:

* Stack:

  ```sh
  sudo pacman -S stack
  ```

* Gcc:

  ```sh
  sudo pacman -S gcc
  ```

* Mercurial (only required for the Isabelle integration):

  ```sh
  sudo pacman -S mercurial
  ```


### openSUSE

Install the following packages:

* Git:

  ```sh
  sudo zypper install git
  ```

* Gcc:

  ```sh
  sudo zypper install gcc
  ```

* Gmp-devel:

  ```sh
  sudo zypper install gmp-devel
  ```

* Stack:

  ```sh
  wget -qO- https://get.haskellstack.org/ | sh
  ```

* Mercurial (only required for the Isabelle integration):

  ```sh
  sudo zypper install mercurial
  ```

* Python-setuptools (only required for the Isabelle integration):

  ```sh
  sudo zypper install python-setuptools
  ```


### Ubuntu

Install the following packages:

* Stack:

  ```sh
  wget -qO- https://get.haskellstack.org/ | sh
  ```

* Git:

  ```sh
  sudo apt-get install git
  ```

* Gcc:

  ```sh
  sudo apt-get install gcc
  ```

* Mercurial (only required for the Isabelle integration):

  ```sh
  sudo apt-get install mercurial
  ```

* Curl (only required for the Isabelle integration):

  ```sh
  sudo apt-get install curl
  ```

* Java (only required for the Isabelle integration):

  The available versions of Java depend on the Ubuntu version you are using.
  If you already have some version of Java installed on your system then you
  do not need to install a new one. (You can check whether java is installed
  e.g. by trying to execute `java --version`.)

  - Ubuntu 20.04:

    ```sh
    sudo apt-get install openjdk-14-jre
    ```

  - Ubuntu 18.04:

    ```sh
    sudo apt-get install openjdk-11-jre
    ```

  - Ubuntu 16.04:

    ```sh
    sudo apt-get install openjdk-8-jre
    ```

  If the output of `echo $JAVA_HOME` is empty, you must also set your
  `JAVA_HOME` path:

  Open the file `~/.bashrc` with a text editor and add the line
  `JAVA_HOME="path/to/java"` at the end of it, where `path/to/java` has to be
  replaced by the path where Java is installed on your system (e.g.
  `/urs/lib/jvm/java-14-openjdk-amd64`).

  Then log out and in again.


### Generic

Install the following packages:

* Git:  
  <https://git-scm.com/download/linux>

* Stack:  
  <https://docs.haskellstack.org/en/stable/install_and_upgrade>

* Mercurial (only required for the Isabelle integration):  
  <https://www.mercurial-scm.org/downloads>

* Curl (only required for the Isabelle integration):  
  <https://curl.se/download.html>
