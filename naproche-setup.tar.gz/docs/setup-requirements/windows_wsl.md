# Windows 10 (WSL)

## 1 Set up a Windows Subsystem for Linux

1.  Open the Windows app _Turn Windows features on or off_

2.  Check the box _Windows Subsystem for Linux_ and click on _OK_

    ![Screenshot: Check Windows Subsystem for Linux](../../lib/images/setup-instructions/windows-features.png)

3.  Reboot your system

4.  Open the Windows app _Microsoft Store_

5.  Install the package _Debian_. (You might install any other Linux distribution as well, but this guide is tailored to _Debian_.)

6.  Start _Debian_. You are asked for a new username and password.


## 2 Enable the desktop mode of your Linux distribution

### 2.1 Install xfce and xrdp

```sh
sudo apt-get install xfce4 xrdp
```


During installation a menu opens where you are asked to select the configuration of your keyboard. You can navigate through it with the tab and arrow keys.

![Screenshot: Keyboard layout selection](../../lib/images/setup-instructions/windows-config-keyboard.png)


### 2.2 Set the default display

```sh
echo 'export DISPLAY=:0.0' >> ~/.bashrc
```

Then reload your `~/.bashrc` by logging out and in again.


### 2.2 Adjust the port for the remote desktop

```sh
sudo sed -i 's/3389/3388/g' /etc/xrdp/xrdp.ini
```


### 2.3 Start the xdrp server

```sh
sudo /etc/init.d/xrdp start
```

Windows opens a _Security Alert_ window. Check the box _Private networks_ and click on _Allow access_.

![Screenshot: Security request](../../lib/images/setup-instructions/windows-security-alert.png)


### 2.4 Establish a remote desktop connection

1.  Open the Windows app _Remote Desktop Connection_

2.  Enter `localhost:3388` in the field _Computer_ and click on _Connect_

    ![Screenshot: Remote desktop connection](../../lib/images/setup-instructions/windows-remote-desktop-connection.png)

3.  Windows opens a new window. Check the box _Don't ask me again for connections to this computer_ and click on _Yes_

    ![Screenshot: Identity cannot be verified](../../lib/images/setup-instructions/windows-identity-cannot-be-verified.png)


### 2.5 Log in to your Linux desktop

Another window appears. Under _Session_ select _Xorg_ and log in with the username and password you have chosen in section 1.1.

![Screenshot: Xrdp login](../../lib/images/setup-instructions/windows-xrdp-login.png)

Now you should find yourself on a Linux desktop.


---

In future you can open your Linux desktop by following the subsequent steps:

  1.  Start the _Debian_ application.

  2.  Execute the command `sudo /etc/init.d/xrdp start && exit`.

  3.  Open the app _Remote Desktop Connection_.

  4.  Enter `localhost:3388` in the field _Computer_ and click on _Connect_ (as above).

  5.  Under _Session_ select _Xorg_ and log in with the username and password (as above).

---


## 3 Install required tools

Naproche comes with a command line interface and an (optional) integration into [Isabelle](https://isabelle.in.tum.de/) which provides a graphical interface via [jEdit](http://www.jedit.org/). To prepare their setup, open a terminal (e.g. from the applications menu) and install the following tools:

* Stack:

  ```sh
  wget -qO- https://get.haskellstack.org/ | sh
  ```

* Git:

  ```sh
  sudo apt-get install git
  ```

* Mercurial (only required for the Isabelle integration):

  ```sh
  sudo apt-get install mercurial
  ```

* Curl (only required for the Isabelle integration):

  ```sh
  sudo apt-get install curl
  ```
