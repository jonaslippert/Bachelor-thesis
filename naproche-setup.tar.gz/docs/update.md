# Update Naproche

* Update the Naproche repository:

  ```sh
  cd .../naproche # Naproche directory
  git pull
  ```

* Build Naproche:

  ```sh
  stack clean
  stack build
  ```

**Skip the following steps if you did not set up the Isabelle integration of
Naproche!**

* Update the Isabelle repository:

  ```sh
  cd .../isabelle # Isabelle directory
  hg pull https://isabelle.sketis.net/repos/isabelle-release
  hg update -C -r Isabelle2021
  isabelle components -a
  ```

* Build Isabelle/Naproche:

  ```sh
  isabelle naproche_build
  ```
